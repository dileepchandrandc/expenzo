package com.expenzo.transactionprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
