package com.expenzo.transactionprocessor.processor.handler;

import org.springframework.stereotype.Service;

import com.expenzo.transactionprocessor.enums.PaymentChannel;
import com.expenzo.transactionprocessor.event.TransactionEvent;
import com.expenzo.transactionprocessor.model.Expense;
import com.expenzo.transactionprocessor.repository.ExpenseRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ExpenseHandler implements TransactionHandler {

    private final ExpenseRepository expenseRepository;

    @Override
    public boolean save(TransactionEvent event) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'save'");
    }

    @Override
    public boolean update(TransactionEvent event) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public boolean delete(TransactionEvent event) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    private Expense toExpense(TransactionEvent event) {
        return Expense.builder()
            .id(event.getId())
            .userId(event.getUserId())
            .amount(event.getAmount())
            .spendOn(event.getTimestamp())
            .title(event.getTitle())
            .description(event.getDescription())
            .bankAccountId(event.getSourceType() == PaymentChannel.BANK_ACCOUNT ? event.getSourceId() : null)
            .creditCardId(event.getSourceType() == PaymentChannel.CREDIT_CARD ? event.getSourceId() : null)
            .debitCardId(event.getSourceType() == PaymentChannel.DEBIT_CARD ? event.getSourceId() : null)
            .walletId(event.getSourceType() == PaymentChannel.WALLET ? event.getSourceId() : null)
            .build();
    }
}
