package com.expenzo.transactionprocessor.enums;

public enum PaymentChannel {
    CREDIT_CARD, DEBIT_CARD, BANK_ACCOUNT, WALLET;
}
