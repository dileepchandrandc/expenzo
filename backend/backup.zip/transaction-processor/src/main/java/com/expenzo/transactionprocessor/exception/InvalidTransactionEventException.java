package com.expenzo.transactionprocessor.exception;

public class InvalidTransactionEventException extends RuntimeException {

    public InvalidTransactionEventException(String message) {
        super(message);
    }
}
