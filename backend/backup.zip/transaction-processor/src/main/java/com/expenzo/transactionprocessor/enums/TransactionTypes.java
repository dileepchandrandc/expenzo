package com.expenzo.transactionprocessor.enums;

public enum TransactionTypes {
    EXPENSE, INCOME, SELF_TRANSFER;
}
