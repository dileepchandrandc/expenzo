package com.expenzo.transactionprocessor.enums;

public enum EventAction {
    CREATE, UPDATE, DELETE;
}
