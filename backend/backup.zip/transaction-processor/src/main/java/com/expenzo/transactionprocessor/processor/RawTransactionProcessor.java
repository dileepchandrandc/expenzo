package com.expenzo.transactionprocessor.processor;

import org.springframework.stereotype.Component;

import com.expenzo.transactionprocessor.enums.PaymentChannel;
import com.expenzo.transactionprocessor.event.TransactionEvent;
import com.expenzo.transactionprocessor.exception.InvalidTransactionEventException;
import com.expenzo.transactionprocessor.model.Expense;
import com.expenzo.transactionprocessor.repository.ExpenseRepository;
import com.expenzo.transactionprocessor.service.PaymentChannelService;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class RawTransactionProcessor {

    private final PaymentChannelService paymentChannelService;
    private final ExpenseRepository expenseRepository;

    public void process(TransactionEvent event) {
        if (event.getAction() == null) {
            return;
        }
        validateEvent(event);
        switch(event.getAction()) {
            case CREATE -> {
                expenseRepository.insert(event);
            }
        }
    }

    private Expense toExpense() {

    }

    /* This method used to validate the transaction events */
    private void validateEvent(TransactionEvent event) {
        //Transaction event must have id and user id
        if (event == null || event.getId() == null || event.getUserId() == null) {
            throw new InvalidTransactionEventException("Missing mandatory fields: id, user id");
        }
        //Transaction must have either source type or destination type
        if (event.getDestType() == null && event.getSourceType() == null) {
            throw new InvalidTransactionEventException("Transaction must have either source or destination details");
        }
        //Destination id is missing
        if (event.getDestType() != null && event.getDestId() == null) {
            throw new InvalidTransactionEventException("Missing destination id");
        }
        //Source id is missing
        if (event.getSourceType() != null && event.getSourceId() == null) {
            throw new InvalidTransactionEventException("Missing source id");
        }
        //TDOD: Validate the transaction source
        if (event.getDestType() != null && !validatePaymentChannel(event.getUserId(), event.getDestType(), event.getDestId())) {
            throw new InvalidTransactionEventException("Invalid destination channel details");
        }
        //TDOD: Validate the transaction destination
        if (event.getSourceType() != null && !validatePaymentChannel(event.getUserId(), event.getSourceType(), event.getSourceId())) {
            throw new InvalidTransactionEventException("Invalid source channel details");
        }
    }

    private boolean validatePaymentChannel(Integer userId, PaymentChannel channel, Integer channelId) {
        return paymentChannelService.validatePaymentChannel(userId, channel, channelId);
    }
}
