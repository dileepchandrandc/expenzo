package com.expenzo.transactionprocessor.repository;

public class SqlQueries {

    class PaymentSource {
        public static String BANK_ACCOUNT_COUNT = "SELECT COUNT(*) FROM bank_account ba WHERE ba.id = ? AND ba.user_id = ?";
        public static String CREDIT_CARD_COUNT = "SELECT COUNT(*) FROM credit_card ca WHERE ca.id = ? AND ca.user_id = ?";
        public static String DEBIT_CARD_COUNT = "SELECT COUNT(*) FROM debit_card da WHERE da.id = ? AND da.user_id = ?";
    }

    class Expense {
        public static String INSERT = "INSERT INTO expense(user_id, spent_on, amount, title, description, bank_account_id, credit_card_id, debit_card_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
    }
}
