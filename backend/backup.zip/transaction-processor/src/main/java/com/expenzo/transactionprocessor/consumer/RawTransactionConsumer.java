package com.expenzo.transactionprocessor.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.expenzo.transactionprocessor.event.TransactionEvent;
import com.expenzo.transactionprocessor.processor.RawTransactionProcessor;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class RawTransactionConsumer {

    private final RawTransactionProcessor processor;

    @KafkaListener(topics = "${expenzo.event.kafka-topic.raw-transaction}")
    public void rawTransactionListener(TransactionEvent event) {
        processor.process(event);
    }
}
