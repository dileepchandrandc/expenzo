package com.expenzo.transactionprocessor.service;

import org.springframework.stereotype.Service;

import com.expenzo.transactionprocessor.enums.PaymentChannel;
import com.expenzo.transactionprocessor.repository.PaymentsRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PaymentChannelService {

    private final PaymentsRepository paymentsRepository;

    public boolean validatePaymentChannel(Integer userId, PaymentChannel channel, Integer channelId) {
        return paymentsRepository.checkPaymentSourceExists(userId, channel, channelId);
    }
}
