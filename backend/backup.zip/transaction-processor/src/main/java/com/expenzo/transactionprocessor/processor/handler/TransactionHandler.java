package com.expenzo.transactionprocessor.processor.handler;

import com.expenzo.transactionprocessor.event.TransactionEvent;

public interface TransactionHandler {

    boolean save(TransactionEvent event);
    boolean update(TransactionEvent event);
    boolean delete(TransactionEvent event);
}
