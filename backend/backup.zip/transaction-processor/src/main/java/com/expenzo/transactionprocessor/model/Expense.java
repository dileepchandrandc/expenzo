package com.expenzo.transactionprocessor.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Expense {

    private Integer id;
    private Integer userId;
    private LocalDateTime spendOn;
    private BigDecimal amount;
    private String title;
    private String description;
    private Integer bankAccountId;
    private Integer creditCardId;
    private Integer debitCardId;
    private Integer walletId;
}
