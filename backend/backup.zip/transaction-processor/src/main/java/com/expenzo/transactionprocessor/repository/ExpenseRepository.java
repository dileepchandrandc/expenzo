package com.expenzo.transactionprocessor.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.expenzo.transactionprocessor.enums.PaymentChannel;
import com.expenzo.transactionprocessor.event.TransactionEvent;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ExpenseRepository {

    private final JdbcTemplate jdbcTemplate;

    public void insert(TransactionEvent event) {
        jdbcTemplate.update(
            SqlQueries.Expense.INSERT, 
            event.getUserId(),
            event.getTimestamp(),
            event.getAmount(),
            event.getTitle(),
            event.getDescription(),
            event.getSourceType() == PaymentChannel.BANK_ACCOUNT ? event.getSourceId() : null,
            event.getSourceType() == PaymentChannel.CREDIT_CARD ? event.getSourceId() : null,
            event.getSourceType() == PaymentChannel.DEBIT_CARD ? event.getSourceId() : null
        );
    }
}
