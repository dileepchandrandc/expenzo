package com.expenzo.transactionprocessor.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransactionMetaData {

    private Integer expenseCategoryId;
}
