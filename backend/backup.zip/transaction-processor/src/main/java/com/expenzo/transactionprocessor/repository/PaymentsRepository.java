package com.expenzo.transactionprocessor.repository;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.expenzo.transactionprocessor.enums.PaymentChannel;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class PaymentsRepository {

    private final JdbcTemplate jdbcTemplate;

    public boolean checkPaymentSourceExists(Integer userId, PaymentChannel channel, Integer channelId) {
        String query = switch (channel) {
            case BANK_ACCOUNT -> SqlQueries.PaymentSource.BANK_ACCOUNT_COUNT;
            case CREDIT_CARD -> SqlQueries.PaymentSource.CREDIT_CARD_COUNT;
            case DEBIT_CARD -> SqlQueries.PaymentSource.DEBIT_CARD_COUNT;
            case WALLET -> null;
        };
        if (query == null) {
            return false;
        }
        Integer count = jdbcTemplate.queryForObject(query, Integer.class, channelId, userId);
        return count != null && count > 0;
    }
}
